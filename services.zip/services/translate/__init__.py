from .google.main import translate_text as g_ajax_translate
from .yandex.main import translate_text as yandex_translate

