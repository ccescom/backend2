from .main import SMS as SMS_V1
from .v2.main import send_sms